import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=78aa65d9"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=78aa65d9"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
import storage from "/src/services/storage.js";
const Blog = ({ blog, handleVote, handleDelete }) => {
  _s();
  const [visible, setVisible] = useState(false);
  const nameOfUser = blog.user ? blog.user.name : "anonymous";
  const style = {
    border: "solid",
    padding: 10,
    borderWidth: 1,
    marginBottom: 5
  };
  const canRemove = blog.user ? blog.user.username === storage.me() : true;
  console.log(blog.user, storage.me(), canRemove);
  return /* @__PURE__ */ jsxDEV("div", { style, className: "blog", children: [
    blog.title,
    " by ",
    blog.author,
    /* @__PURE__ */ jsxDEV("button", { style: { marginLeft: 3 }, onClick: () => setVisible(!visible), children: visible ? "hide" : "view" }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    visible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("a", { href: blog.url, children: blog.url }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 16
      }, this) }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "likes ",
        blog.likes,
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            style: { marginLeft: 3 },
            onClick: () => handleVote(blog),
            children: "like"
          },
          void 0,
          false,
          {
            fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
            lineNumber: 51,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
        lineNumber: 49,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: nameOfUser }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 11
      }, this),
      canRemove && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleDelete(blog), children: "remove" }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
        lineNumber: 59,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
};
_s(Blog, "OGsIWlGlwYpVUqIrDReJ1GWx7rw=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.shape({
    url: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    likes: PropTypes.number.isRequired,
    user: PropTypes.object
  }).isRequired,
  handleVote: PropTypes.func.isRequired,
  handleDelete: PropTypes.func.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCTixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFDaEMsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxhQUFhO0FBRXBCLE1BQU1DLE9BQU9BLENBQUMsRUFBRUMsTUFBTUMsWUFBWUMsYUFBYSxNQUFNO0FBQUFDLEtBQUE7QUFDbkQsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlULFNBQVMsS0FBSztBQUU1QyxRQUFNVSxhQUFhTixLQUFLTyxPQUFPUCxLQUFLTyxLQUFLQyxPQUFPO0FBRWhELFFBQU1DLFFBQVE7QUFBQSxJQUNaQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxJQUNiQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxRQUFNQyxZQUFZZCxLQUFLTyxPQUFPUCxLQUFLTyxLQUFLUSxhQUFhakIsUUFBUWtCLEdBQUcsSUFBSTtBQUVwRUMsVUFBUUMsSUFBSWxCLEtBQUtPLE1BQU1ULFFBQVFrQixHQUFHLEdBQUdGLFNBQVM7QUFFOUMsU0FDRSx1QkFBQyxTQUFJLE9BQWMsV0FBVSxRQUMxQmQ7QUFBQUEsU0FBS21CO0FBQUFBLElBQU07QUFBQSxJQUFLbkIsS0FBS29CO0FBQUFBLElBQ3RCLHVCQUFDLFlBQU8sT0FBTyxFQUFFQyxZQUFZLEVBQUUsR0FBRyxTQUFTLE1BQU1oQixXQUFXLENBQUNELE9BQU8sR0FDakVBLG9CQUFVLFNBQVMsVUFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ0EsV0FDQyx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsU0FBSSxpQ0FBQyxPQUFFLE1BQU1KLEtBQUtzQixLQUFNdEIsZUFBS3NCLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkIsS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLE1BQ3RDLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBQ0t0QixLQUFLdUI7QUFBQUEsUUFDWjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTyxFQUFFRixZQUFZLEVBQUU7QUFBQSxZQUN2QixTQUFTLE1BQU1wQixXQUFXRCxJQUFJO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBS00sd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2hCUSxhQUFhLHVCQUFDLFlBQU8sU0FBUyxNQUFNWixhQUFhRixJQUFJLEdBQUUsc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFZDtBQUFBLFNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsT0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUNHLEdBM0NLSixNQUFJO0FBQUF5QixLQUFKekI7QUE2Q05BLEtBQUswQixZQUFZO0FBQUEsRUFDZnpCLE1BQU1ILFVBQVU2QixNQUFNO0FBQUEsSUFDcEJKLEtBQUt6QixVQUFVOEIsT0FBT0M7QUFBQUEsSUFDdEJULE9BQU90QixVQUFVOEIsT0FBT0M7QUFBQUEsSUFDeEJMLE9BQU8xQixVQUFVZ0MsT0FBT0Q7QUFBQUEsSUFDeEJyQixNQUFNVixVQUFVaUM7QUFBQUEsRUFDbEIsQ0FBQyxFQUFFRjtBQUFBQSxFQUNIM0IsWUFBWUosVUFBVWtDLEtBQUtIO0FBQUFBLEVBQzNCMUIsY0FBY0wsVUFBVWtDLEtBQUtIO0FBQy9CO0FBRUEsZUFBZTdCO0FBQUksSUFBQXlCO0FBQUFRLGFBQUFSLElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiUHJvcFR5cGVzIiwic3RvcmFnZSIsIkJsb2ciLCJibG9nIiwiaGFuZGxlVm90ZSIsImhhbmRsZURlbGV0ZSIsIl9zIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJuYW1lT2ZVc2VyIiwidXNlciIsIm5hbWUiLCJzdHlsZSIsImJvcmRlciIsInBhZGRpbmciLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsImNhblJlbW92ZSIsInVzZXJuYW1lIiwibWUiLCJjb25zb2xlIiwibG9nIiwidGl0bGUiLCJhdXRob3IiLCJtYXJnaW5MZWZ0IiwidXJsIiwibGlrZXMiLCJfYyIsInByb3BUeXBlcyIsInNoYXBlIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIm51bWJlciIsIm9iamVjdCIsImZ1bmMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcbmltcG9ydCBzdG9yYWdlIGZyb20gJy4uL3NlcnZpY2VzL3N0b3JhZ2UnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCBoYW5kbGVWb3RlLCBoYW5kbGVEZWxldGUgfSkgPT4ge1xuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBuYW1lT2ZVc2VyID0gYmxvZy51c2VyID8gYmxvZy51c2VyLm5hbWUgOiAnYW5vbnltb3VzJ1xuXG4gIGNvbnN0IHN0eWxlID0ge1xuICAgIGJvcmRlcjogJ3NvbGlkJyxcbiAgICBwYWRkaW5nOiAxMCxcbiAgICBib3JkZXJXaWR0aDogMSxcbiAgICBtYXJnaW5Cb3R0b206IDUsXG4gIH1cblxuICBjb25zdCBjYW5SZW1vdmUgPSBibG9nLnVzZXIgPyBibG9nLnVzZXIudXNlcm5hbWUgPT09IHN0b3JhZ2UubWUoKSA6IHRydWVcblxuICBjb25zb2xlLmxvZyhibG9nLnVzZXIsIHN0b3JhZ2UubWUoKSwgY2FuUmVtb3ZlKVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17c3R5bGV9IGNsYXNzTmFtZT0nYmxvZyc+XG4gICAgICB7YmxvZy50aXRsZX0gYnkge2Jsb2cuYXV0aG9yfVxuICAgICAgPGJ1dHRvbiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzIH19IG9uQ2xpY2s9eygpID0+IHNldFZpc2libGUoIXZpc2libGUpfT5cbiAgICAgICAge3Zpc2libGUgPyAnaGlkZScgOiAndmlldyd9XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIHt2aXNpYmxlICYmIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2PjxhIGhyZWY9e2Jsb2cudXJsfT57YmxvZy51cmx9PC9hPjwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICBsaWtlcyB7YmxvZy5saWtlc31cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogMyB9fVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVWb3RlKGJsb2cpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBsaWtlXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PntuYW1lT2ZVc2VyfTwvZGl2PlxuICAgICAgICAgIHtjYW5SZW1vdmUgJiYgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUoYmxvZyl9PlxuICAgICAgICAgICAgcmVtb3ZlXG4gICAgICAgICAgPC9idXR0b24+fVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5CbG9nLnByb3BUeXBlcyA9IHtcbiAgYmxvZzogUHJvcFR5cGVzLnNoYXBlKHtcbiAgICB1cmw6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICB0aXRsZTogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxuICAgIGxpa2VzOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgdXNlcjogUHJvcFR5cGVzLm9iamVjdCxcbiAgfSkuaXNSZXF1aXJlZCxcbiAgaGFuZGxlVm90ZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgaGFuZGxlRGVsZXRlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dcbiJdLCJmaWxlIjoiL2hvbWUvYnJ1aC9Db2RlL25vZGVqcy9mdWxsc3RhY2tvcGVucy9mdWxsc3RhY2tvcGVuc3VibWlzc2lvbnMvcGFydDcvYmxvZ2FwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9