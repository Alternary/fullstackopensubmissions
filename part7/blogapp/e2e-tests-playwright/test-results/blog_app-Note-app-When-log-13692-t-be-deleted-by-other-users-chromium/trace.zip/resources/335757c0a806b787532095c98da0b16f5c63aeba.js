import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=78aa65d9"; const useState = __vite__cjsImport3_react["useState"]; const forwardRef = __vite__cjsImport3_react["forwardRef"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"];
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = { display: visible ? "none" : "" };
  const showWhenVisible = { display: visible ? "" : "none" };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx",
      lineNumber: 41,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.displayName = "Togglable";
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Togglable.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCUixTQUFTQSxVQUFVQyxZQUFZQywyQkFBMkI7QUFFMUQsTUFBTUMsWUFBU0MsR0FBR0gsV0FBVUksS0FBQUQsR0FBQyxDQUFDRSxPQUFPQyxRQUFRO0FBQUFILEtBQUE7QUFDM0MsUUFBTSxDQUFDSSxTQUFTQyxVQUFVLElBQUlULFNBQVMsS0FBSztBQUU1QyxRQUFNVSxrQkFBa0IsRUFBRUMsU0FBU0gsVUFBVSxTQUFTLEdBQUc7QUFDekQsUUFBTUksa0JBQWtCLEVBQUVELFNBQVNILFVBQVUsS0FBSyxPQUFPO0FBRXpELFFBQU1LLG1CQUFtQkEsTUFBTTtBQUM3QkosZUFBVyxDQUFDRCxPQUFPO0FBQUEsRUFDckI7QUFFQU4sc0JBQW9CSyxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQ0xNO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU9ILGlCQUNWLGlDQUFDLFlBQU8sU0FBU0csa0JBQW1CUCxnQkFBTVEsZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBT0YsaUJBQ1ROO0FBQUFBLFlBQU1TO0FBQUFBLE1BQ1AsdUJBQUMsWUFBTyxTQUFTRixrQkFBa0Isc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKLEdBQUMsa0NBQUM7QUFBQUcsTUEzQkliO0FBNkJOQSxVQUFVYyxjQUFjO0FBRXhCLGVBQWVkO0FBQVMsSUFBQUUsSUFBQVc7QUFBQUUsYUFBQWIsSUFBQTtBQUFBYSxhQUFBRixLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJmb3J3YXJkUmVmIiwidXNlSW1wZXJhdGl2ZUhhbmRsZSIsIlRvZ2dsYWJsZSIsIl9zIiwiX2MiLCJwcm9wcyIsInJlZiIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwiaGlkZVdoZW5WaXNpYmxlIiwiZGlzcGxheSIsInNob3dXaGVuVmlzaWJsZSIsInRvZ2dsZVZpc2liaWxpdHkiLCJidXR0b25MYWJlbCIsImNoaWxkcmVuIiwiX2MyIiwiZGlzcGxheU5hbWUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCBmb3J3YXJkUmVmLCB1c2VJbXBlcmF0aXZlSGFuZGxlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IFRvZ2dsYWJsZSA9IGZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCF2aXNpYmxlKVxuICB9XG5cbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShyZWYsICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9nZ2xlVmlzaWJpbGl0eVxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9Pntwcm9wcy5idXR0b25MYWJlbH08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfT5cbiAgICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PmNhbmNlbDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn0pXG5cblRvZ2dsYWJsZS5kaXNwbGF5TmFtZSA9ICdUb2dnbGFibGUnXG5cbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZVxuIl0sImZpbGUiOiIvaG9tZS9icnVoL0NvZGUvbm9kZWpzL2Z1bGxzdGFja29wZW5zL2Z1bGxzdGFja29wZW5zdWJtaXNzaW9ucy9wYXJ0Ny9ibG9nYXBwL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1RvZ2dsYWJsZS5qc3gifQ==