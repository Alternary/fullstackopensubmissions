import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=78aa65d9"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const createRef = __vite__cjsImport3_react["createRef"];
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import storage from "/src/services/storage.js";
import Login from "/src/components/Login.jsx";
import Blog from "/src/components/Blog.jsx";
import NewBlog from "/src/components/NewBlog.jsx";
import Notification from "/src/components/Notification.jsx?t=1754657504038";
import Togglable from "/src/components/Togglable.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [user, setUser] = useState(null);
  const [notification, setNotification] = useState(null);
  useEffect(() => {
    blogService.getAll().then(
      (blogs2) => setBlogs(blogs2)
    );
  }, []);
  useEffect(() => {
    const user2 = storage.loadUser();
    if (user2) {
      setUser(user2);
    }
  }, []);
  const blogFormRef = createRef();
  const notify = (message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 5e3);
  };
  const handleLogin = async (credentials) => {
    try {
      const user2 = await loginService.login(credentials);
      setUser(user2);
      storage.saveUser(user2);
      notify(`Welcome back, ${user2.name}`);
    } catch (error) {
      notify("Wrong credentials", "error");
    }
  };
  const handleCreate = async (blog) => {
    const newBlog = await blogService.create(blog);
    setBlogs(blogs.concat(newBlog));
    notify(`Blog created: ${newBlog.title}, ${newBlog.author}`);
    blogFormRef.current.toggleVisibility();
  };
  const handleVote = async (blog) => {
    console.log("updating", blog);
    const updatedBlog = await blogService.update(blog.id, {
      ...blog,
      likes: blog.likes + 1
    });
    notify(`You liked ${updatedBlog.title} by ${updatedBlog.author}`);
    setBlogs(blogs.map((b) => b.id === blog.id ? updatedBlog : b));
  };
  const handleLogout = () => {
    setUser(null);
    storage.removeUser();
    notify(`Bye, ${user.name}!`);
  };
  const handleDelete = async (blog) => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`)) {
      await blogService.remove(blog.id);
      setBlogs(blogs.filter((b) => b.id !== blog.id));
      notify(`Blog ${blog.title}, by ${blog.author} removed`);
    }
  };
  if (!user) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { notification }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
        lineNumber: 105,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Login, { doLogin: handleLogin }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this);
  }
  const byLikes = (a, b) => b.likes - a.likes;
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { notification }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " logged in",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 117,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(NewBlog, { doCreate: handleCreate }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 124,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    blogs.sort(byLikes).map(
      (blog) => /* @__PURE__ */ jsxDEV(
        Blog,
        {
          blog,
          handleVote,
          handleDelete
        },
        blog.id,
        false,
        {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
          lineNumber: 127,
          columnNumber: 7
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx",
    lineNumber: 114,
    columnNumber: 5
  }, this);
};
_s(App, "uQU0a91LnmWLRDTkSLgSoFnV7zw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBGUixTQUFTQSxVQUFVQyxXQUFXQyxpQkFBaUI7QUFFL0MsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2UsTUFBTUMsT0FBTyxJQUFJaEIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ2lCLGNBQWNDLGVBQWUsSUFBSWxCLFNBQVMsSUFBSTtBQUVyREMsWUFBVSxNQUFNO0FBQ2RFLGdCQUFZZ0IsT0FBTyxFQUFFQztBQUFBQSxNQUFLLENBQUFQLFdBQ3hCQyxTQUFTRCxNQUFLO0FBQUEsSUFDaEI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMWixZQUFVLE1BQU07QUFDZCxVQUFNYyxRQUFPVixRQUFRZ0IsU0FBUztBQUM5QixRQUFJTixPQUFNO0FBQ1JDLGNBQVFELEtBQUk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNTyxjQUFjcEIsVUFBVTtBQUU5QixRQUFNcUIsU0FBU0EsQ0FBQ0MsU0FBU0MsT0FBTyxjQUFjO0FBQzVDUCxvQkFBZ0IsRUFBRU0sU0FBU0MsS0FBSyxDQUFDO0FBQ2pDQyxlQUFXLE1BQU07QUFDZlIsc0JBQWdCLElBQUk7QUFBQSxJQUN0QixHQUFHLEdBQUk7QUFBQSxFQUNUO0FBRUEsUUFBTVMsY0FBYyxPQUFPQyxnQkFBZ0I7QUFDekMsUUFBSTtBQUNGLFlBQU1iLFFBQU8sTUFBTVgsYUFBYXlCLE1BQU1ELFdBQVc7QUFDakRaLGNBQVFELEtBQUk7QUFDWlYsY0FBUXlCLFNBQVNmLEtBQUk7QUFDckJRLGFBQU8saUJBQWlCUixNQUFLZ0IsSUFBSSxFQUFFO0FBQUEsSUFDckMsU0FBU0MsT0FBTztBQUNkVCxhQUFPLHFCQUFxQixPQUFPO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBRUEsUUFBTVUsZUFBZSxPQUFPQyxTQUFTO0FBQ25DLFVBQU1DLFVBQVUsTUFBTWhDLFlBQVlpQyxPQUFPRixJQUFJO0FBQzdDcEIsYUFBU0QsTUFBTXdCLE9BQU9GLE9BQU8sQ0FBQztBQUM5QlosV0FBTyxpQkFBaUJZLFFBQVFHLEtBQUssS0FBS0gsUUFBUUksTUFBTSxFQUFFO0FBQzFEakIsZ0JBQVlrQixRQUFRQyxpQkFBaUI7QUFBQSxFQUN2QztBQUVBLFFBQU1DLGFBQWEsT0FBT1IsU0FBUztBQUNqQ1MsWUFBUUMsSUFBSSxZQUFZVixJQUFJO0FBQzVCLFVBQU1XLGNBQWMsTUFBTTFDLFlBQVkyQyxPQUFPWixLQUFLYSxJQUFJO0FBQUEsTUFDcEQsR0FBR2I7QUFBQUEsTUFDSGMsT0FBT2QsS0FBS2MsUUFBUTtBQUFBLElBQ3RCLENBQUM7QUFFRHpCLFdBQU8sYUFBYXNCLFlBQVlQLEtBQUssT0FBT08sWUFBWU4sTUFBTSxFQUFFO0FBQ2hFekIsYUFBU0QsTUFBTW9DLElBQUksQ0FBQUMsTUFBS0EsRUFBRUgsT0FBT2IsS0FBS2EsS0FBS0YsY0FBY0ssQ0FBQyxDQUFDO0FBQUEsRUFDN0Q7QUFFQSxRQUFNQyxlQUFlQSxNQUFNO0FBQ3pCbkMsWUFBUSxJQUFJO0FBQ1pYLFlBQVErQyxXQUFXO0FBQ25CN0IsV0FBTyxRQUFRUixLQUFLZ0IsSUFBSSxHQUFHO0FBQUEsRUFDN0I7QUFFQSxRQUFNc0IsZUFBZSxPQUFPbkIsU0FBUztBQUNuQyxRQUFJb0IsT0FBT0MsUUFBUSxlQUFlckIsS0FBS0ksS0FBSyxPQUFPSixLQUFLSyxNQUFNLEVBQUUsR0FBRztBQUNqRSxZQUFNcEMsWUFBWXFELE9BQU90QixLQUFLYSxFQUFFO0FBQ2hDakMsZUFBU0QsTUFBTTRDLE9BQU8sQ0FBQVAsTUFBS0EsRUFBRUgsT0FBT2IsS0FBS2EsRUFBRSxDQUFDO0FBQzVDeEIsYUFBTyxRQUFRVyxLQUFLSSxLQUFLLFFBQVFKLEtBQUtLLE1BQU0sVUFBVTtBQUFBLElBQ3hEO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQ3hCLE1BQU07QUFDVCxXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLE1BQ1QsdUJBQUMsZ0JBQWEsZ0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLE1BQ3pDLHVCQUFDLFNBQU0sU0FBU1ksZUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBSDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUo7QUFFQSxRQUFNK0IsVUFBVUEsQ0FBQ0MsR0FBR1QsTUFBTUEsRUFBRUYsUUFBUVcsRUFBRVg7QUFFdEMsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLGdCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUN6Qyx1QkFBQyxTQUNFakM7QUFBQUEsV0FBS2dCO0FBQUFBLE1BQUs7QUFBQSxNQUNYLHVCQUFDLFlBQU8sU0FBU29CLGNBQWEsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxhQUFVLGFBQVksbUJBQWtCLEtBQUs3QixhQUM1QyxpQ0FBQyxXQUFRLFVBQVVXLGdCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NwQixNQUFNK0MsS0FBS0YsT0FBTyxFQUFFVDtBQUFBQSxNQUFJLENBQUFmLFNBQ3ZCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQUhLQSxLQUFLYTtBQUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNkI7QUFBQSxJQUUvQjtBQUFBLE9BbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQkE7QUFFSjtBQUFDbkMsR0F6R0tELEtBQUc7QUFBQWtELEtBQUhsRDtBQTJHTixlQUFlQTtBQUFHLElBQUFrRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJjcmVhdGVSZWYiLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsInN0b3JhZ2UiLCJMb2dpbiIsIkJsb2ciLCJOZXdCbG9nIiwiTm90aWZpY2F0aW9uIiwiVG9nZ2xhYmxlIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlciIsInNldFVzZXIiLCJub3RpZmljYXRpb24iLCJzZXROb3RpZmljYXRpb24iLCJnZXRBbGwiLCJ0aGVuIiwibG9hZFVzZXIiLCJibG9nRm9ybVJlZiIsIm5vdGlmeSIsIm1lc3NhZ2UiLCJ0eXBlIiwic2V0VGltZW91dCIsImhhbmRsZUxvZ2luIiwiY3JlZGVudGlhbHMiLCJsb2dpbiIsInNhdmVVc2VyIiwibmFtZSIsImVycm9yIiwiaGFuZGxlQ3JlYXRlIiwiYmxvZyIsIm5ld0Jsb2ciLCJjcmVhdGUiLCJjb25jYXQiLCJ0aXRsZSIsImF1dGhvciIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiaGFuZGxlVm90ZSIsImNvbnNvbGUiLCJsb2ciLCJ1cGRhdGVkQmxvZyIsInVwZGF0ZSIsImlkIiwibGlrZXMiLCJtYXAiLCJiIiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlVXNlciIsImhhbmRsZURlbGV0ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJyZW1vdmUiLCJmaWx0ZXIiLCJieUxpa2VzIiwiYSIsInNvcnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgY3JlYXRlUmVmIH0gZnJvbSAncmVhY3QnXG5cbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IHN0b3JhZ2UgZnJvbSAnLi9zZXJ2aWNlcy9zdG9yYWdlJ1xuaW1wb3J0IExvZ2luIGZyb20gJy4vY29tcG9uZW50cy9Mb2dpbidcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IE5ld0Jsb2cgZnJvbSAnLi9jb21wb25lbnRzL05ld0Jsb2cnXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25vdGlmaWNhdGlvbiwgc2V0Tm90aWZpY2F0aW9uXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+XG4gICAgICBzZXRCbG9ncyhibG9ncylcbiAgICApXG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdXNlciA9IHN0b3JhZ2UubG9hZFVzZXIoKVxuICAgIGlmICh1c2VyKSB7XG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBibG9nRm9ybVJlZiA9IGNyZWF0ZVJlZigpXG5cbiAgY29uc3Qgbm90aWZ5ID0gKG1lc3NhZ2UsIHR5cGUgPSAnc3VjY2VzcycpID0+IHtcbiAgICBzZXROb3RpZmljYXRpb24oeyBtZXNzYWdlLCB0eXBlIH0pXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXROb3RpZmljYXRpb24obnVsbClcbiAgICB9LCA1MDAwKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoY3JlZGVudGlhbHMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbihjcmVkZW50aWFscylcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHN0b3JhZ2Uuc2F2ZVVzZXIodXNlcilcbiAgICAgIG5vdGlmeShgV2VsY29tZSBiYWNrLCAke3VzZXIubmFtZX1gKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBub3RpZnkoJ1dyb25nIGNyZWRlbnRpYWxzJywgJ2Vycm9yJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVDcmVhdGUgPSBhc3luYyAoYmxvZykgPT4ge1xuICAgIGNvbnN0IG5ld0Jsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZylcbiAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQobmV3QmxvZykpXG4gICAgbm90aWZ5KGBCbG9nIGNyZWF0ZWQ6ICR7bmV3QmxvZy50aXRsZX0sICR7bmV3QmxvZy5hdXRob3J9YClcbiAgICBibG9nRm9ybVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlVm90ZSA9IGFzeW5jIChibG9nKSA9PiB7XG4gICAgY29uc29sZS5sb2coJ3VwZGF0aW5nJywgYmxvZylcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZShibG9nLmlkLCB7XG4gICAgICAuLi5ibG9nLFxuICAgICAgbGlrZXM6IGJsb2cubGlrZXMgKyAxXG4gICAgfSlcblxuICAgIG5vdGlmeShgWW91IGxpa2VkICR7dXBkYXRlZEJsb2cudGl0bGV9IGJ5ICR7dXBkYXRlZEJsb2cuYXV0aG9yfWApXG4gICAgc2V0QmxvZ3MoYmxvZ3MubWFwKGIgPT4gYi5pZCA9PT0gYmxvZy5pZCA/IHVwZGF0ZWRCbG9nIDogYikpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgc2V0VXNlcihudWxsKVxuICAgIHN0b3JhZ2UucmVtb3ZlVXNlcigpXG4gICAgbm90aWZ5KGBCeWUsICR7dXNlci5uYW1lfSFgKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGJsb2cpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nICR7YmxvZy50aXRsZX0gYnkgJHtibG9nLmF1dGhvcn1gKSkge1xuICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UucmVtb3ZlKGJsb2cuaWQpXG4gICAgICBzZXRCbG9ncyhibG9ncy5maWx0ZXIoYiA9PiBiLmlkICE9PSBibG9nLmlkKSlcbiAgICAgIG5vdGlmeShgQmxvZyAke2Jsb2cudGl0bGV9LCBieSAke2Jsb2cuYXV0aG9yfSByZW1vdmVkYClcbiAgICB9XG4gIH1cblxuICBpZiAoIXVzZXIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPGgyPmJsb2dzPC9oMj5cbiAgICAgICAgPE5vdGlmaWNhdGlvbiBub3RpZmljYXRpb249e25vdGlmaWNhdGlvbn0gLz5cbiAgICAgICAgPExvZ2luIGRvTG9naW49e2hhbmRsZUxvZ2lufSAvPlxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9XG5cbiAgY29uc3QgYnlMaWtlcyA9IChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlc1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5ibG9nczwvaDI+XG4gICAgICA8Tm90aWZpY2F0aW9uIG5vdGlmaWNhdGlvbj17bm90aWZpY2F0aW9ufSAvPlxuICAgICAgPGRpdj5cbiAgICAgICAge3VzZXIubmFtZX0gbG9nZ2VkIGluXG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5cbiAgICAgICAgICBsb2dvdXRcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9XCJjcmVhdGUgbmV3IGJsb2dcIiByZWY9e2Jsb2dGb3JtUmVmfT5cbiAgICAgICAgPE5ld0Jsb2cgZG9DcmVhdGU9e2hhbmRsZUNyZWF0ZX0gLz5cbiAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAge2Jsb2dzLnNvcnQoYnlMaWtlcykubWFwKGJsb2cgPT5cbiAgICAgICAgPEJsb2dcbiAgICAgICAgICBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgYmxvZz17YmxvZ31cbiAgICAgICAgICBoYW5kbGVWb3RlPXtoYW5kbGVWb3RlfVxuICAgICAgICAgIGhhbmRsZURlbGV0ZT17aGFuZGxlRGVsZXRlfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBcbiJdLCJmaWxlIjoiL2hvbWUvYnJ1aC9Db2RlL25vZGVqcy9mdWxsc3RhY2tvcGVucy9mdWxsc3RhY2tvcGVuc3VibWlzc2lvbnMvcGFydDcvYmxvZ2FwcC9mcm9udGVuZC9zcmMvQXBwLmpzeCJ9