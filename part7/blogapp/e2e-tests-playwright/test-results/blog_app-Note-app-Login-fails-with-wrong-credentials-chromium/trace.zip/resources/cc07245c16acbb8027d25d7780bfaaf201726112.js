import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({ notification }) => {
  if (!notification) {
    return null;
  }
  const { message, type } = notification;
  const style = {
    backgroundColor: "lightgrey",
    margin: "10px",
    padding: "10px",
    border: "2px solid",
    borderColor: type === "success" ? "green" : "red",
    borderRadius: "5px"
  };
  return /* @__PURE__ */ jsxDEV("div", { style, children: message }, void 0, false, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Notification.jsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJKLE1BQU1BLGVBQWVBLENBQUMsRUFBRUMsYUFBYSxNQUFNO0FBQ3pDLE1BQUksQ0FBQ0EsY0FBYztBQUNqQixXQUFPO0FBQUEsRUFDVDtBQUVBLFFBQU0sRUFBRUMsU0FBU0MsS0FBSyxJQUFJRjtBQUUxQixRQUFNRyxRQUFRO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLGFBQWFOLFNBQVMsWUFBWSxVQUFVO0FBQUEsSUFDNUNPLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUNGUixxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDUyxLQXJCS1g7QUF1Qk4sZUFBZUE7QUFBWSxJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTm90aWZpY2F0aW9uIiwibm90aWZpY2F0aW9uIiwibWVzc2FnZSIsInR5cGUiLCJzdHlsZSIsImJhY2tncm91bmRDb2xvciIsIm1hcmdpbiIsInBhZGRpbmciLCJib3JkZXIiLCJib3JkZXJDb2xvciIsImJvcmRlclJhZGl1cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBOb3RpZmljYXRpb24gPSAoeyBub3RpZmljYXRpb24gfSkgPT4ge1xuICBpZiAoIW5vdGlmaWNhdGlvbikge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBjb25zdCB7IG1lc3NhZ2UsIHR5cGUgfSA9IG5vdGlmaWNhdGlvblxuXG4gIGNvbnN0IHN0eWxlID0ge1xuICAgIGJhY2tncm91bmRDb2xvcjogJ2xpZ2h0Z3JleScsXG4gICAgbWFyZ2luOiAnMTBweCcsXG4gICAgcGFkZGluZzogJzEwcHgnLFxuICAgIGJvcmRlcjogJzJweCBzb2xpZCcsXG4gICAgYm9yZGVyQ29sb3I6IHR5cGUgPT09ICdzdWNjZXNzJyA/ICdncmVlbicgOiAncmVkJyxcbiAgICBib3JkZXJSYWRpdXM6ICc1cHgnLFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXtzdHlsZX0+XG4gICAgICB7bWVzc2FnZX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25cbiJdLCJmaWxlIjoiL2hvbWUvYnJ1aC9Db2RlL25vZGVqcy9mdWxsc3RhY2tvcGVucy9mdWxsc3RhY2tvcGVuc3VibWlzc2lvbnMvcGFydDcvYmxvZ2FwcC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Ob3RpZmljYXRpb24uanN4In0=