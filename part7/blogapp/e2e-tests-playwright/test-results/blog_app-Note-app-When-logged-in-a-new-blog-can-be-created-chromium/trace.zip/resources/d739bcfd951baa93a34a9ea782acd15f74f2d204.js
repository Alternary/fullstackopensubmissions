import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Login.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=78aa65d9"; const useState = __vite__cjsImport3_react["useState"];
const Login = ({ doLogin }) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const handleLogin = (event) => {
    event.preventDefault();
    doLogin({ username, password });
    setUsername("");
    setPassword("");
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Username:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          "data-testid": "username",
          value: username,
          onChange: (e) => setUsername(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
          lineNumber: 37,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Password:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          "data-testid": "password",
          onChange: (e) => setPassword(e.target.value)
        },
        void 0,
        false,
        {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
          lineNumber: 45,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("input", { type: "submit", value: "Login" }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_s(Login, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/Login.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsUUFBUUEsQ0FBQyxFQUFFQyxRQUFRLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUwsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ00sVUFBVUMsV0FBVyxJQUFJUCxTQUFTLEVBQUU7QUFFM0MsUUFBTVEsY0FBY0EsQ0FBQ0MsVUFBVTtBQUM3QkEsVUFBTUMsZUFBZTtBQUNyQlIsWUFBUSxFQUFFRSxVQUFVRSxTQUFTLENBQUM7QUFDOUJELGdCQUFZLEVBQUU7QUFDZEUsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCO0FBRUEsU0FDRSx1QkFBQyxVQUFLLFVBQVVDLGFBQ2Q7QUFBQSwyQkFBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxlQUFZO0FBQUEsVUFDWixPQUFPSjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ08sTUFBTU4sWUFBWU0sRUFBRUMsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStDO0FBQUEsU0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxXQUFLO0FBQUE7QUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPUDtBQUFBQSxVQUNQLGVBQVk7QUFBQSxVQUNaLFVBQVUsQ0FBQ0ssTUFBTUosWUFBWUksRUFBRUMsT0FBT0MsS0FBSztBQUFBO0FBQUEsUUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSStDO0FBQUEsU0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxXQUFNLE1BQUssVUFBUyxPQUFNLFdBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxPQWpCcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVKO0FBQUNWLEdBaENLRixPQUFLO0FBQUFhLEtBQUxiO0FBa0NOLGVBQWVBO0FBQUssSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTG9naW4iLCJkb0xvZ2luIiwiX3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5cbmNvbnN0IExvZ2luID0gKHsgZG9Mb2dpbiB9KSA9PiB7XG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZG9Mb2dpbih7IHVzZXJuYW1lLCBwYXNzd29yZCB9KVxuICAgIHNldFVzZXJuYW1lKCcnKVxuICAgIHNldFBhc3N3b3JkKCcnKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgPGxhYmVsPlxuICAgICAgICBVc2VybmFtZTpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIGRhdGEtdGVzdGlkPSd1c2VybmFtZSdcbiAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9IC8+XG4gICAgICA8L2xhYmVsPlxuICAgICAgPGxhYmVsPlxuICAgICAgICBQYXNzd29yZDpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSAvPlxuICAgICAgPC9sYWJlbD5cbiAgICAgIDxpbnB1dCB0eXBlPVwic3VibWl0XCIgdmFsdWU9XCJMb2dpblwiIC8+XG4gICAgPC9mb3JtPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luXG4iXSwiZmlsZSI6Ii9ob21lL2JydWgvQ29kZS9ub2RlanMvZnVsbHN0YWNrb3BlbnMvZnVsbHN0YWNrb3BlbnN1Ym1pc3Npb25zL3BhcnQ3L2Jsb2dhcHAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW4uanN4In0=