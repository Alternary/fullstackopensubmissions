import axios from "/node_modules/.vite/deps/axios.js?v=78aa65d9"

const login = async (credentials) => {
  const response = await axios.post('/api/login', credentials)
  return response.data
}

export default { login }
