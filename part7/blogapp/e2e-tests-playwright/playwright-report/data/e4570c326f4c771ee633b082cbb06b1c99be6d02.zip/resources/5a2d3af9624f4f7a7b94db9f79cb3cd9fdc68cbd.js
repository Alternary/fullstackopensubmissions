import {
  require_react
} from "/node_modules/.vite/deps/chunk-WQMOH32Y.js?v=78aa65d9";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=78aa65d9";
export default require_react();
//# sourceMappingURL=react.js.map
