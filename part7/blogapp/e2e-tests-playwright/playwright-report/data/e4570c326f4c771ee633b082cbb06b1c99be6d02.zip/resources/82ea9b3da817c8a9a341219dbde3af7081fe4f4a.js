import {
  require_client
} from "/node_modules/.vite/deps/chunk-EW3DKD2S.js?v=78aa65d9";
import "/node_modules/.vite/deps/chunk-WALXKXZM.js?v=78aa65d9";
import "/node_modules/.vite/deps/chunk-WQMOH32Y.js?v=78aa65d9";
import "/node_modules/.vite/deps/chunk-5WWUZCGV.js?v=78aa65d9";
export default require_client();
//# sourceMappingURL=react-dom_client.js.map
