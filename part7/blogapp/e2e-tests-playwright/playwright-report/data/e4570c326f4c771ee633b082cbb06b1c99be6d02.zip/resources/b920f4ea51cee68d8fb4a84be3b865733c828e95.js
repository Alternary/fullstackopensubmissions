import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NewBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=78aa65d9"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=78aa65d9"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
const NewBlog = ({ doCreate }) => {
  _s();
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [author, setAuthor] = useState("");
  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };
  const handleUrlChange = (event) => {
    setUrl(event.target.value);
  };
  const handleAuthorChange = (event) => {
    setAuthor(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    doCreate({ title, url, author });
    setAuthor("");
    setTitle("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create a New Blog" }, void 0, false, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "Title:" }, void 0, false, {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            "data-testid": "title",
            value: title,
            onChange: handleTitleChange
          },
          void 0,
          false,
          {
            fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
            lineNumber: 53,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "URL:" }, void 0, false, {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
          lineNumber: 61,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            "data-testid": "url",
            value: url,
            onChange: handleUrlChange
          },
          void 0,
          false,
          {
            fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
            lineNumber: 62,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { children: "Author:" }, void 0, false, {
          fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            "data-testid": "author",
            value: author,
            onChange: handleAuthorChange
          },
          void 0,
          false,
          {
            fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
            lineNumber: 71,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Create" }, void 0, false, {
        fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
};
_s(NewBlog, "BmxPEKrRQpBvBiXQlJiVTyOw0q4=");
_c = NewBlog;
export default NewBlog;
var _c;
$RefreshReg$(_c, "NewBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/bruh/Code/nodejs/fullstackopens/fullstackopensubmissions/part7/blogapp/frontend/src/components/NewBlog.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCTixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFFaEMsTUFBTUMsVUFBVUEsQ0FBQyxFQUFFQyxTQUFTLE1BQU07QUFBQUMsS0FBQTtBQUNoQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUwsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ00sS0FBS0MsTUFBTSxJQUFJUCxTQUFTLEVBQUU7QUFDakMsUUFBTSxDQUFDUSxRQUFRQyxTQUFTLElBQUlULFNBQVMsRUFBRTtBQUV2QyxRQUFNVSxvQkFBb0JBLENBQUNDLFVBQVU7QUFDbkNOLGFBQVNNLE1BQU1DLE9BQU9DLEtBQUs7QUFBQSxFQUM3QjtBQUVBLFFBQU1DLGtCQUFrQkEsQ0FBQ0gsVUFBVTtBQUNqQ0osV0FBT0ksTUFBTUMsT0FBT0MsS0FBSztBQUFBLEVBQzNCO0FBRUEsUUFBTUUscUJBQXFCQSxDQUFDSixVQUFVO0FBQ3BDRixjQUFVRSxNQUFNQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNRyxlQUFlQSxDQUFDTCxVQUFVO0FBQzlCQSxVQUFNTSxlQUFlO0FBQ3JCZixhQUFTLEVBQUVFLE9BQU9FLEtBQUtFLE9BQU8sQ0FBQztBQUMvQkMsY0FBVSxFQUFFO0FBQ1pKLGFBQVMsRUFBRTtBQUNYRSxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxpQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsSUFDckIsdUJBQUMsVUFBSyxVQUFVUyxjQUNkO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsUUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsZUFBWTtBQUFBLFlBQ1osT0FBT1o7QUFBQUEsWUFDUCxVQUFVTTtBQUFBQTtBQUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk4QjtBQUFBLFdBTmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sb0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsZUFBWTtBQUFBLFlBQ1osT0FBT0o7QUFBQUEsWUFDUCxVQUFVUTtBQUFBQTtBQUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0QjtBQUFBLFdBTjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sdUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsUUFDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsZUFBWTtBQUFBLFlBQ1osT0FBT047QUFBQUEsWUFDUCxVQUFVTztBQUFBQTtBQUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkrQjtBQUFBLFdBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQTVCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLE9BL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0E7QUFFSjtBQUFDWixHQTVES0YsU0FBTztBQUFBaUIsS0FBUGpCO0FBOEROLGVBQWVBO0FBQU8sSUFBQWlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiTmV3QmxvZyIsImRvQ3JlYXRlIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwidXJsIiwic2V0VXJsIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwiaGFuZGxlVGl0bGVDaGFuZ2UiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwiaGFuZGxlVXJsQ2hhbmdlIiwiaGFuZGxlQXV0aG9yQ2hhbmdlIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5ld0Jsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBOZXdCbG9nID0gKHsgZG9DcmVhdGUgfSkgPT4ge1xuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXJsLCBzZXRVcmxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFthdXRob3IsIHNldEF1dGhvcl0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCBoYW5kbGVUaXRsZUNoYW5nZSA9IChldmVudCkgPT4ge1xuICAgIHNldFRpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVVybENoYW5nZSA9IChldmVudCkgPT4ge1xuICAgIHNldFVybChldmVudC50YXJnZXQudmFsdWUpXG4gIH1cblxuICBjb25zdCBoYW5kbGVBdXRob3JDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBzZXRBdXRob3IoZXZlbnQudGFyZ2V0LnZhbHVlKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIGRvQ3JlYXRlKHsgdGl0bGUsIHVybCwgYXV0aG9yIH0pXG4gICAgc2V0QXV0aG9yKCcnKVxuICAgIHNldFRpdGxlKCcnKVxuICAgIHNldFVybCgnJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5DcmVhdGUgYSBOZXcgQmxvZzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWw+VGl0bGU6PC9sYWJlbD5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPSd0aXRsZSdcbiAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVUaXRsZUNoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWw+VVJMOjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXJsJ1xuICAgICAgICAgICAgdmFsdWU9e3VybH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVVcmxDaGFuZ2V9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsPkF1dGhvcjo8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J2F1dGhvcidcbiAgICAgICAgICAgIHZhbHVlPXthdXRob3J9XG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQXV0aG9yQ2hhbmdlfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5DcmVhdGU8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOZXdCbG9nXG4iXSwiZmlsZSI6Ii9ob21lL2JydWgvQ29kZS9ub2RlanMvZnVsbHN0YWNrb3BlbnMvZnVsbHN0YWNrb3BlbnN1Ym1pc3Npb25zL3BhcnQ3L2Jsb2dhcHAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTmV3QmxvZy5qc3gifQ==